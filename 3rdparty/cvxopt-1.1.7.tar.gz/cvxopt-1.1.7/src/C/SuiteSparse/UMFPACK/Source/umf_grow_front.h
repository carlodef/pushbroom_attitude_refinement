/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL Int UMF_grow_front
(
    NumericType *Numeric,
    Int fnr2,
    Int fnc2,
    WorkType *Work,
    Int do_what
) ;
