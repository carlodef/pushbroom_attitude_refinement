#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_set_stats.c"
