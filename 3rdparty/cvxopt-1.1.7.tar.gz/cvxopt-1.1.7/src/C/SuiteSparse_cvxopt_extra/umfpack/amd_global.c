#include "../../SuiteSparse/AMD/Source/amd_global.c"
