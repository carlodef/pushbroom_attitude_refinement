#define DLONG

#include "../../SuiteSparse/AMD/Source/amd_order.c"
