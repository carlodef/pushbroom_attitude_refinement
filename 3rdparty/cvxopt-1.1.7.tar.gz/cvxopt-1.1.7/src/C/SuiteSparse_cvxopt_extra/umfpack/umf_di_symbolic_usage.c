#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_symbolic_usage.c"
