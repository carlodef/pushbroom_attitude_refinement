#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_build_tuples.c"
