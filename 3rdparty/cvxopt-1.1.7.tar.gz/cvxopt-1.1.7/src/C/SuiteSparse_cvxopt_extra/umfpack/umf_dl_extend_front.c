#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_extend_front.c"
