#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_init_front.c"
